No back after login

Simple paste this code to login page in the head section


          <SCRIPT type="text/javascript">
    window.history.forward();
    function noBack() { window.history.forward(); }
</SCRIPT>
</HEAD>
<BODY onload="noBack();" 
    onpageshow="if (event.persisted) noBack();" onunload="">