  'paypal.standard.ipn',
    'paypal.standard.pdt',
     'paypal.standard',
    'paypal.pro',


 pip install django-paypal
 pip install M2Crypto


 type in terminal

 Encrypted buttons require certificates. Create a private key:

openssl genrsa -out paypal.pem 1024

Create a public key:

openssl req -new -key paypal.pem -x509 -days 365 -out pubpaypal.pem



 