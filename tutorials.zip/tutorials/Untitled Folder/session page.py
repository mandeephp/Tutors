views.py file

#################################################forsessioons######################################################################################
from django.contrib.auth.signals import user_logged_in
from .models import UserSession


def user_logged_in_handler(sender, request, user, **kwargs):
    UserSession.objects.get_or_create(user = user, session_id = request.session.session_key)

user_logged_in.connect(user_logged_in_handler)

def delete_user_sessions(user):
    user_sessions = UserSession.objects.filter(user = user)
    for user_session in user_session:
        user_session.session.delete()
###################################################################################################################################################3







########################################################## sessions##################################################################################
models.py

from django.conf import settings
from django.db import models
from django.contrib.sessions.models import Session

class UserSession(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL)
    session = models.ForeignKey(Session)
  

settings.py

SESSION_COOKIE_AGE = 10 # timeout of a user


##################################################################for login required##################################################################

settings.py

LOGIN_REDIRECT_URL ='/index/'

LOGIN_URL = '/users/login/'


urls.py


from django.contrib.auth.decorators import login_required
url(r'^become_tutor', login_required(views.become_tutor_form_view), name='become_tutor'),