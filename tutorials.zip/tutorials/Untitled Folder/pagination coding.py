pagination coding


views.py coding

def tutor_in_chd_short_view(request):
    s = Tutor_Chandigarh.objects.all()
    paginator = Paginator(s, 5)
    page = request.GET.get('page')
    try:
        s = paginator.page(page)
    except PageNotAnInteger:
        s = paginator.page(1)
    except EmptyPage:
        s = paginator.page(paginator.num_pages)
    return render(request, 'app/chd_tutor_short.html', {'s':s})






html page coding

{% for i in s %}
<div id="short_detail">

<table>       
<img  src='{{ i.Image.url }}' height="200" width="200" border="1"/>  
<tr>
<th>Name</th><td>{{i.Name}}</td>
</tr>
<tr>
<th>Subjects Taught By Tutor</th><td>{{i.Subjects}}</td>
</tr>
<tr>
<th>Area</th><td>{{i.Area}}</td>
</tr>
<tr>
<th>Charges Per Hour</th><td>{{i.Charges_Per_Hour}}  </td>
</tr>
</table>
<a id="a1" href={% url 'chd_tutor' id=i.Tutor_id %} > View Full Profile </a>

</div>
{% endfor %}

<div class="pagination">
    <span class="step-links">
        {% if s.has_previous %}
            <a href="?page={{ s.previous_page_number }}">previous</a>
        {% endif %}

        <span class="current">
            Page {{ s.number }} of {{s.paginator.num_pages }}.
        </span>

        {% if s.has_next %}
            <a href="?page={{ contacts.next_page_number }}">next</a>
        {% endif %}
    </span>
</div>

</div>