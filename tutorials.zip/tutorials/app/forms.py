from django import forms
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.forms.extras.widgets import SelectDateWidget
from django.core.exceptions import ValidationError
from django.contrib.auth import (
    authenticate,
    get_user_model,
    login,
    logout
)

###payu money
'''from payu.utils import generate_hash

class PayUForm(forms.Form):
    # payu specific fields
    key = forms.CharField()
    hash = forms.CharField(required=False)

    # cart order related fields
    txnid = forms.CharField()
    productinfo = forms.CharField()
    amount = forms.DecimalField(decimal_places=2)

    # buyer details
    firstname = forms.CharField()
    lastname = forms.CharField(required=False)
    email = forms.EmailField()
    phone = forms.RegexField(regex=r'\d{10}', min_length=10, max_length=10)
    address1 = forms.CharField(required=False)
    address2 = forms.CharField(required=False)
    city = forms.CharField(required=False)
    state = forms.CharField(required=False)
    country = forms.CharField(required=False)
    zipcode = forms.RegexField(regex=r'\d{6}', min_length=6, max_length=6, required=False)
    
    # merchant's side related fields
    furl = forms.URLField()
    surl = forms.URLField()
    curl = forms.URLField(required=False)
    codurl = forms.URLField(required=False)
    touturl = forms.URLField(required=False)
    udf1 = forms.CharField(required=False)
    udf2 = forms.CharField(required=False)
    udf3 = forms.CharField(required=False)
    udf4 = forms.CharField(required=False)
    udf5 = forms.CharField(required=False)
    pg = forms.CharField(required=False)
    drop_category = forms.CharField(required=False)
    custom_note = forms.CharField(required=False)
    note_category = forms.CharField(required=False)
    
    def clean(self):
        cleaned_data = super(PayUForm, self).clean()
        cleaned_data['hash'] = generate_hash(cleaned_data)
        return cleaned_data'''

#######################################################


class contact(forms.ModelForm):
    class Meta:
        model=contact
        fields=('name','email','phone','message','company_name','subject')
        

class date(forms.Form):
    dob = forms.DateField(widget=SelectDateWidget(years=range(2016,1959,-1)))


class reset_password(forms.Form):
    old_Passwrd=forms.CharField(widget=forms.PasswordInput)
    New_Password=forms.CharField(widget=forms.PasswordInput,label=("New Password"))
    Confirm_Password=forms.CharField(widget=forms.PasswordInput, label=("Confirm Password"))

class best_tutor_form(forms.ModelForm):
    class Meta:
        model = best_tutor
        fields = ('Area', 'Gender', 'Subjects', 'Classes', 'Experience','Age', 'Charges_Per_Hour', 'Ratings')


class UserLoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)
    
    def clean(self, *args, **kwargs):
        username = self.cleaned_data.get("username")
        password = self.cleaned_data.get("password")
        
        #user_qs = User.objects.filter(username=username)
        #if user_qs.count() == 1:
        #   user = user_qs.first()
        if username and password:
            user = authenticate(username=username, password=password)
            if not user:
                raise forms.ValidationError("This user does not exist")
            if not user.check_password(password):
                raise forms.ValidationError("Incorrect password")
            if not user.is_active:
                raise forms.ValidationError("This user is no longer active")
            return super(UserLoginForm, self).clean(*args, **kwargs)
                        
    def clean_remember_me(self):
        """clean method for remember_me """
        remember_me = self.cleaned_data.get['remember_me']
        if not remember_me:
            settings.SESSION_EXPIRE_AT_BROWSER_CLOSE = True
        else:
            settings.SESSION_EXPIRE_AT_BROWSER_CLOSE = False
            return remember_me



class ChangePasswordForm(forms.Form):
    newpassword= forms.CharField(widget=forms.PasswordInput(attrs=dict(required=True, max_length=30)), label=("New Password"))
    renewpasssword=forms.CharField(widget=forms.PasswordInput(attrs=dict(required=True, max_length=30)), label=("Retype New Password"))            





class UserRegisterForm(forms.ModelForm):
    #Student_Name= forms.CharField(max_length=300)
    email = forms.EmailField(label="Email Address")
    email2 = forms.EmailField(label="Confirm Email")
    password = forms.CharField(widget=forms.PasswordInput)
    password2 = forms.CharField(widget=forms.PasswordInput, label="Confirm Password")
    image = forms.ImageField() 
    class Meta:
        model = User
        fields = ['username','password','password2','email','email2','image']

    def clean_password2(self):
        print(self.cleaned_data)
        password = self.cleaned_data.get('password')
        password2 = self.cleaned_data.get('password2')
        print(password, password2)
        if password != password2:
            raise forms.ValidationError("Passwords don't match")
        else:
            return password
    
    def clean_email2(self):
        print(self.cleaned_data)
        email = self.cleaned_data.get('email')
        email2 = self.cleaned_data.get('email2')
        print(email, email2)
        if email != email2:
            raise forms.ValidationError("Email addresses don't match")
        email_qs = User.objects.filter(email=email)
        if  email_qs.exists():
            raise forms.ValidationError("This email has already been registered")
        else:
            return email




class Student_Form(forms.ModelForm):
    class Meta:
        model = student
        fields = ['Student_Name', 'Student_Class', 'Student_Area', 'Tution_Subject']

'''class tutor_in_chandigarh_form(forms.ModelForm):
    class Meta:
        model = tutor_in_chandigarh
        fields = ['id', 'Name', 'Subjects', 'Area', 'Experience', 'Mobile_No', 'Email', 'Charges_Per_Hour']'''




class become_tutor_form(forms.ModelForm):
    def clean_Resume(self):
        data = self.cleaned_data['Resume']
        try:
            url_validate(data)
        except ValidationError:
            raise self.fields['Resume'].error_messages['Please Select .doc or .pdf file formats']
        return data

    class Meta:
        model = become_tutor
        fields = ['Name', 'Age','Gender','Email','Mobile_No','Address','Interested_In','Qualifications','Select_Subjects','Interested_Classes','About_You','Select_Area','Image', 'Resume']



  
class hire_tutor_form(forms.ModelForm):
    class Meta:
        model = Hire_Tutor
        fields = ['Name', 'Age','Gender', 'Email','Mobile_No','Address','Standard','School','Select_Area', 'Subject','Tution_Area']



class tutor_mohali_form(forms.ModelForm):
    class Meta:
        model = Tutor_Mohali
        fields = ['Image']
