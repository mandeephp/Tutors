from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(contact)
admin.site.register(student)
admin.site.register(Tutor_Chandigarh)
admin.site.register(Tutor_Mohali)
admin.site.register(Tutor_Kharar)
admin.site.register(become_tutor)
admin.site.register(Hire_Tutor)
admin.site.register(Teacher)
admin.site.register(best_tutor)
admin.site.register(Foo)
admin.site.register(UserProfile)
admin.site.register(UserSession)
