from django.shortcuts import render, redirect
from .forms import *
#from django.core.context_processors import csrf
from django.views.decorators import csrf
from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from django.template import RequestContext
import hashlib, datetime, random
from django.contrib import auth
from django.core.mail import send_mail
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from django.contrib.auth import views as auth_views
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import cache_control
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib import messages
#from facebook_auth.urls import redirect_uri
from django.contrib.auth import (
    authenticate,
    get_user_model,
    login,
    logout
)

from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.core.urlresolvers import reverse



def change_password(request):
    newpassword = request.POST.get("newpassword")
    renewpasssword = request.POST.get("renewpasssword")
    username=request.user.username
    if newpassword == renewpasssword:
        if request.method == 'GET':
            form = ChangePasswordForm()
        else:
            u = User.objects.get(username__exact=username)
            u.set_password(newpassword)
            u.save()
            return redirect('/index')
    else:
        return redirect('/index')
    return render(request,'changepassword.html', {'form': form,})

##########################################################to generaete csv file###################################################################
import csv
@login_required
def some_csv(request):
    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="somefilename.csv"'

    writer = csv.writer(response)
    writer.writerow(['First row', 'Foo', 'Bar', 'Baz'])
    writer.writerow(['Second row', 'A', 'B', 'C', '"Testing"', "Hello world. This csv file is working.@ Mandeep Thakur"])
    return response

#####################################################################################################################################################


################################################################# to generate pdf file###############################################################
from reportlab.pdfgen import canvas
def some_view(request):
    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="Mandeep_Thakur.pdf"'

    # Create the PDF object, using the response object as its "file."
    p = canvas.Canvas(response)

    # Draw things on the PDF. Here's where the PDF generation happens.
    # See the ReportLab documentation for the full list of functionality.
    p.drawString(10, 10, "Hello world. This pdf file is working.@ Mandeep Thakur")

    # Close the PDF object cleanly, and we're done.
    p.showPage()
    p.save()
    return response

#####################################################################################################################################################

#######################################################################forsessioons##################################################################
from django.contrib.auth.signals import user_logged_in
from .models import UserSession


def user_logged_in_handler(sender, request, user, **kwargs):
    UserSession.objects.get_or_create(user = user, session_id = request.session.session_key)

user_logged_in.connect(user_logged_in_handler)

def delete_user_sessions(user):
    user_sessions = UserSession.objects.filter(user = user)
    for user_session in user_session:
        user_session.session.delete()
#################################################################3###################################################################################




######################################################facebook_login @ Google login #################################################################
def facebook_login(request):
    context.update({
        'redirect_uri': redirect_uri('/login/success', '/login/fail'),
        'client_id': settings.FACEBOOK_APP_ID,
        'scope': 'email'
    })


def google_login(request):
    return render(request, 'google_login.html', {})
####################################################################################################################################################

def index(request):
    return render(request,'app/index.html')



def index1(request):
    return render(request,'app/index1.html',{})



def about_us(request):
    return render(request,'app/about_us.html')



'''@cache_control(no_cache=True, must_revalidate=True)
def func(request):
    return render(request, 'app/index1.html', {})
    return'''



'''def tutor_in_chandigarh_view(request):
    chd = Tutor_Chandigarh.objects.all()
    return render(request, 'app/chd_tutor.html', {'chd':chd})
    chds = request.GET.get("q")
    if chds:
        chd = chd.objects.filter(
            Q(Name__icontains=chds)|
            Q(Subjects__icontains=chds)|
            Q(Area__icontains=chds)|
            Q(Charges_Per_Hour__icontains=chds)
            ).distinct()'''


#################################################################### Search View ####################################################################
def search(request):
    if 'q' in request.GET and request.GET['q']:
        q = request.GET['q']
        chd_tutor = Tutor_Chandigarh.objects.filter(
            Q(Name__icontains=q)|
            Q(Subjects__icontains=q)|
            Q(Area__icontains=q)|
            Q(Charges_Per_Hour__icontains=q)|
            Q(Age__icontains=q)
            ).distinct() 
        paginator = Paginator(q, 5)
        page = request.GET.get('page')
        try:
            q = paginator.page(page)
        except PageNotAnInteger:
            q = paginator.page(1)
        except EmptyPage:
            q = paginator.page(paginator.num_pages)            
        return render(request, 'app/search_results.html', {'chd_tutor':chd_tutor,'q': q})
    else:
        return HttpResponse('Please submit a Valid search term.')

#####################################################################################################################

def services(request):
    return render(request,'app/services.html')



def portfolio(request):
    return render(request,'app/portfolio.html')



def blog_item(request):
    return render(request,'app/blog_item.html')



def pricing(request):
    return render(request,'app/pricing.html')



def blog(request):
    return render(request,'app/blog.html')



def tutor_payment(request):
    return render(request,'app/hire_tutor_payment.html')




def error(request):
    return render(request,'app/404.html')



def shortcodes(request):
    return render(request,'app/shortcodes.html')


def delete(request, id):
    query = People.objects.get(pk=id)
    query.delete()
    return HttpResponse("Deleted!")


#Search result full view
def full_details_search_view(request, id):
    r = Tutor_Chandigarh.objects.get(id=id)
    return render(request, 'app/full_search.html', {'r':r})


def tutors_view(request, id):
    global m
    m = Teacher.objects.filter(teacher_id=id)
    return render(request, 'app/Teacher.html',{'m':m})


def delete_tutor_view(request):
    global m
    m.delete()
    return HttpResponse('Tutor Has Been Blocked')


def teacher_short_view(request):
    q=Teacher.objects.all()
    paginator = Paginator(q, 2)
    page = request.GET.get('page')
    try:
        q = paginator.page(page)
    except PageNotAnInteger:
        q = paginator.page(1)
    except EmptyPage:
        q = paginator.page(paginator.num_pages)
    return render(request, 'app/teacher_short.html', {'q':q})


def tutors_in_chd_view(request, id):
    global chd
    chd = Tutor_Chandigarh.objects.filter(Tutor_id=id)
    return render(request, 'app/chd_tutor.html', {'chd':chd})



def delete_tutor_chandigarh(request):
    global chd
    chd.delete()
    return HttpResponse('Tutor Has Been Blocked')




def tutor_in_chd_short_view(request):
    s = Tutor_Chandigarh.objects.all()
    paginator = Paginator(s, 5)
    page = request.GET.get('page')
    try:
        s = paginator.page(page)
    except PageNotAnInteger:
        s = paginator.page(1)
    except EmptyPage:
        s = paginator.page(paginator.num_pages)
    return render(request, 'app/chd_tutor_short.html', {'s':s})
    

'''def teacher_view_full(request):
        i=request.POST.get('tf')
        print(i)
        l= Teacher.objects.get(teacher_id=i)
        return render(request,'app/Teacher.html', {'l':l})'''


def neww(request):
    return render(request, 'app/new.html', {})


def delete_tutor_mohali(request):
    global mhl
    mhl.delete()
    return HttpResponse('Tutor Has Been Blocked')


def tutor_in_mohali_view(request, id):
    global mhl
    mhl = Tutor_Mohali.objects.filter(Tutor_id=id)
    return render(request, 'app/mohali_tutor.html', {'mhl':mhl})



def tutor_in_mohali_short_view(request):
    m = Tutor_Mohali.objects.all()
    paginator = Paginator(m, 2)
    page = request.GET.get('page')
    try:
        m = paginator.page(page)
    except PageNotAnInteger:
        m = paginator.page(1)
    except EmptyPage:
        m = paginator.page(paginator.num_pages)
    return render(request, 'app/mhl_tutor_short.html', {'m':m})



def tutor_in_kharar_view(request, id):
    global khr
    khr = Tutor_Kharar.objects.filter(Tutor_id=id)
    return render(request, 'app/Khr_tutor.html', {'khr':khr})




def delete_tutor_kharar(request):
    global khr
    khr.delete()
    return HttpResponse('Tutor Has Been Blocked')




def tutor_in_kharar_short_view(request):
    k = Tutor_Kharar.objects.all()
    paginator = Paginator(k, 2)
    page = request.GET.get('page')
    try:
        k = paginator.page(page)
    except PageNotAnInteger:
        k = paginator.page(1)
    except EmptyPage:
        k = paginator.page(paginator.num_pages)
    return render(request, 'app/khr_tutor_short.html', {'k':k})




@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def contact_us(request):
    return render(request,'app/contact_us.html')





########################################################################Change Password##############################################################
def change_password(request):
    Old_password = request.POST.get("Old_password")
    new_Passsword = request.POST.get("New_Passsword")
    Confirm_Passsword = request.POST.get("Confirm_Passsword")
    username=request.user.username
    if newpassword == renewpasssword:
        if request.method == 'GET':
            form = reset_password()
        else:
            u = User.objects.get(username__exact=username)
            u.set_password(newpassword)
            u.save()
            return redirect('/users/login')
    else:
        return redirect('/change/password/')
    return render(request,'app/changepassword.html', {'form': form,})


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def contactview(request):
    if request.method=="POST":
        f=contact(request.POST)
        if f.is_valid():
            f.save()
            return HttpResponse('Thanks For Contacting With Us')
    else:
        f=contact()
        return render(request,'app/contact_us.html',{'f':f})


'''def hire_tutor_form_view(request):
    if request.method=='POST':
        form = hire_tutor_form(request.POST)
        if form.is_valid():
            form.save()
            #return render(request, 'app/become_tutor_redirect.html',{})
            return HttpResponse('Thanks For Contacting With Us')
    else:
        form = become_tutor_form()
        return render(request, 'app/hire_tutor.html', {'form':form})'''


def best_tutor_view(request):
    form = best_tutor_form(request.POST or None)
    if form.is_valid():
        form.save()
        #return HttpResponse('Thanks For Contacting With Us')
        return HttpResponse('Your Query Has Been Sucessfully Registered With Us. We Will Find Out Best Tutor According To Your Query')
    return render(request, 'app/best_tutor.html', {'form':form})


'''def payu_view(request):
    form = PayUForm(request.POST or None)
    if form.is_valid():
        form.save()
        #return HttpResponse('Thanks For Contacting With Us')
        return HttpResponse('Your Query Has Been Sucessfully Registered With Us. We Will Find Out Best Tutor According To Your Query')
    return render(request, 'payu.html', {'form':form})'''

 

def date_view(request):
    form=date(request.POST or None)
    if form.is_valid():
        form.save()
        return HttpResponse('yo')
    return render(request, 'date.html', {'form':form})


def hire_tutor_form_view(request):
    form = hire_tutor_form(request.POST or None)
    if form.is_valid():
        form.save()
        #return HttpResponse('Thanks For Contacting With Us')
        return render(request, 'app/hire_tutor_redirect.html',{})
    return render(request, 'app/hire_tutor.html', {'form':form})


def become_tutor_form_view(request):
    q = become_tutor_form(request.POST, request.FILES or None)
    if q.is_valid():
        q.save()
        #return HttpResponse('Thanks For Contacting With Us')
        return render(request, 'app/become_tutor_redirect.html',{})
    return render(request, 'app/become_tutor.html', {'q':q})



def student_view(request):
    if request.method=='POST':
        form = Student_Form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('Sucessfully Done We will Get You Soon')
    else:
        form = Student_Form()
        return render(request, 'app/student_detail.html', {'form':form})


'''def login(request, user):
    return HttpResponseRedirect(reverse('app:student_view'))'''


def login_view(request):
    print(request.user.is_authenticated())
    w="Welcome"
    title = "Login"
    form = UserLoginForm(request.POST or None)
    if form.is_valid():
        username = form.cleaned_data.get("username")
        password = form.cleaned_data.get("password")
        user = authenticate(username=username, password=password)
        login(request, user)
        return render(request,'app/index1.html',{'username':username,'w':w,'user':user})
        #return redirect('student_view')
        
        
    return render(request, "app/login.html", {"form":form, "title":title})
 

'''def login_user(request, template_name='app/login.html', extra_context=None):
    response = auth_views.login(request, template_name) 
    if request.POST.has_key('remember_me'):
        request.session.set_expiry(1209600)'''


'''def change_password(request):
    newpassword = request.POST.get("newpassword")
    renewpasssword = request.POST.get("renewpasssword")
    username=request.user.username
    if newpassword == renewpasssword:
        if request.method == 'GET':
            form = ChangePasswordForm()
        else:
            u = User.objects.get(username__exact=username)
            u.set_password(newpassword)
            u.save()
            return HttpResponse('/users/account')
    else:
        return redirect('/change/password/')
    return render(request,'app/changepassword.html', {'form': form,})

def change_pass(request, User):
    global n
    title = "Change password"
    n = User.objects.get(User=User)
    return render(request,'app/change_password.html', {"n":n, "title":title})

response = HttpResponse()  # Created a HttpResponse
response['Cache-Control'] = 'no-cache'  # Set Cache-Control Header'''


def register_view(request):
    print(request.user.is_authenticated())
   
    form = UserRegisterForm(request.POST, request.FILES or None)
    if form.is_valid():
        user = form.save(commit=False)
        password = form.cleaned_data.get('password')
        im = form.cleaned_data.get('image')
        user.set_password(password)
        user.save()
        x = UserProfile(user=user, image=im)
        x.save()
        new_user = authenticate(username=user.username, password=password)
        login(request, new_user)
        return render(request, 'app/register_sucessfull.html',{})
    
    context = {
        "form": form,
        
    }
    return render(request, "app/register.html", context)
  


@cache_control(no_cache=True, must_revalidate=True)  
@login_required 
def logout_view(request):
    logout(request)
    return redirect("/")

