from __future__ import unicode_literals

from django.db import models, migrations
from PIL import Image
from django.contrib.contenttypes.fields import GenericRelation
from star_ratings.models import Rating
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
## sessions
from django.conf import settings
from django.db import models
from django.contrib.sessions.models import Session

class UserSession(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL)
    session = models.ForeignKey(Session)
  

###

PROFILE_TYPES = (
    (u'INST', 'Institute'),
    (u'TUT', 'Tutor'),
    (u'Stu', 'Student'),
)

# used just to define the relation between User and Profile
class UserProfile(models.Model):
    user = models.OneToOneField(User)
    image = models.ImageField(upload_to='photo')

    def __str__(self):
    	return self.user

# common fields reside here
class Profile(models.Model):
    verified = models.BooleanField(default=False)



class Foo(models.Model):
    bar = models.CharField(max_length=100)
    ratings = GenericRelation(Rating, related_query_name='foos')
    def __str__(self):
    	return self.bar


class contact(models.Model):
	name=models.CharField(max_length=200,blank=False)
	email=models.EmailField(max_length=400,blank=False,primary_key=True)
	phone=models.IntegerField(blank=False, default='1234567890')
	message=models.TextField(max_length=900,blank=False)
	company_name=models.CharField(max_length=300,blank=False)
	subject=models.CharField(max_length=400,blank=False)
	
	def __str__(self):
		return self.name


class Teacher(models.Model):
	Name=models.CharField(max_length=100,blank=False)
	teacher_id=models.CharField(max_length=200,primary_key=True)
	CATEGORY_CHOICES = (
            ('Male','Male'),
            ('Female','Female'),
            )
	Gender = models.CharField(max_length=200, choices = CATEGORY_CHOICES, default='Male')
	Age = models.IntegerField(default=18)
	Mobile_No = models.IntegerField(blank=False, default='1234567890')
	Email = models.EmailField(blank=False, default='jaseir@gmail.com')
	Qualification=models.CharField(max_length=100,blank=False)
	Experience=models.CharField(max_length=100,blank=False)
	Subject=models.CharField(max_length=500,blank=False)
	Charges=models.CharField(max_length=100,blank=False)
	CATEGORY_CHOICES = (
            ('Chandigarh','Chandigarh'),
            ('Mohali','Mohali'),
            ('Kharar','Kharar'),
            )
	Area = models.CharField(max_length=900, blank=False, choices = CATEGORY_CHOICES)
	About_Tutor=models.TextField(max_length=1000,blank=False)
	image=models.ImageField(upload_to='photo')

	def __unicode__(self):
		return self.Name




class student(models.Model):
	Student_Name = models.CharField(max_length=300, blank=False)
	Student_Class = models.CharField(max_length=300,blank=False)
	SELECT='sl'
	CHANDIGARH='ch'
	MOHALI='mh'
	KHARAR='kr'
	BELONGI='bl'
	area_choices=(
		(SELECT, 'Select'),
		(CHANDIGARH, 'Chandigarh'),
		(MOHALI, 'Mohali'),
		(KHARAR, 'Kharar'),
		(BELONGI, 'Belongi')

		)
	Student_Area=models.CharField(max_length=3, choices=area_choices,default=SELECT)
	Tution_Subject = models.CharField(max_length=300,blank=False)
	#ratings = GenericRelation(Rating, related_query_name='foos')
	#email=models.EmailField(max_length=400,blank=False)
	def __str__(self):
		return self.Student_Name

class Tutor_Chandigarh(models.Model):
	class Meta:
		verbose_name_plural='Tutor_Chandigarh'
	Tutor_id=models.CharField(max_length=200,primary_key=True, default=100)
	Name = models.CharField(max_length=300, blank=False)
	CATEGORY_CHOICES = (
            ('Male','Male'),
            ('Female','Female'),
            )
	Gender = models.CharField(max_length=200, choices = CATEGORY_CHOICES)
	Age = models.IntegerField(default=18)
	Qualifications = models.CharField(max_length=200, blank=False, default='MCA')
	Subjects = models.CharField(max_length=600, blank=False)
	CATEGORY_CHOICES = (
            ('Chandigarh','Chandigarh'),
            ('Mohali','Mohali'),
            ('Kharar','Kharar'),
            )
	Area = models.CharField(max_length=900, blank=False, choices = CATEGORY_CHOICES, default='Chandigarh')
	Experience = models.CharField(max_length=600, blank=False, default='2 Years')
	Mobile_No = models.IntegerField(blank=False, default='1234567890')
	Email = models.EmailField(max_length=300, blank=False)
	Charges_Per_Hour = models.CharField(max_length=300)
	Image = models.ImageField(upload_to='photo')
	About_Tutor = models.TextField(max_length=1000, blank=False, default='About')
	def __str__(self):
		return self.Name



class Tutor_Kharar(models.Model):
	class Meta:
		verbose_name_plural='Tutor_Kharar'
	Tutor_id=models.CharField(max_length=200,primary_key=True, default=100)
	Name = models.CharField(max_length=300, blank=False)
	CATEGORY_CHOICES = (
            ('Male','Male'),
            ('Female','Female'),
            )
	Gender = models.CharField(max_length=200, choices = CATEGORY_CHOICES)
	Age = models.IntegerField(default=18)
	Qualifications = models.CharField(max_length=200, blank=False, default='MCA')
	Subjects = models.CharField(max_length=600, blank=False)
	CATEGORY_CHOICES = (
            ('Chandigarh','Chandigarh'),
            ('Mohali','Mohali'),
            ('Kharar','Kharar'),
            )
	Area = models.CharField(max_length=900, blank=False, choices=CATEGORY_CHOICES, default='Kharar')
	Experience = models.CharField(max_length=600, blank=False, default='2 Years')
	Mobile_No = models.IntegerField(blank=False, default='1234567890')
	Email = models.EmailField(max_length=300, blank=False)
	Charges_Per_Hour = models.CharField(max_length=300)
	Image = models.ImageField(upload_to='photo')
	About_Tutor = models.TextField(max_length=1000, blank=False, default='About')
	def __str__(self):
		return self.Name

class Tutor_Mohali(models.Model):
	class Meta:
		verbose_name_plural='Tutor_Mohali'
	Tutor_id=models.CharField(max_length=200,primary_key=True, default=100)
	Name = models.CharField(max_length=300, blank=False)
	CATEGORY_CHOICES = (
            ('Male','Male'),
            ('Female','Female'),
            )
	Gender = models.CharField(max_length=200, choices = CATEGORY_CHOICES)
	Age = models.IntegerField(default=18)
	Qualifications = models.CharField(max_length=200, blank=False, default='MCA')
	Subjects = models.CharField(max_length=600, blank=False)
	CATEGORY_CHOICES = (
            ('Chandigarh','Chandigarh'),
            ('Mohali','Mohali'),
            ('Kharar','Kharar'),
            )
	Area = models.CharField(max_length=900, blank=False, choices=CATEGORY_CHOICES, default='Mohali')
	Experience = models.CharField(max_length=600, blank=False, default='2 Years')
	Mobile_No = models.IntegerField(blank=False, default='1234567890')
	Email = models.EmailField(max_length=300, blank=False)
	Charges_Per_Hour = models.CharField(max_length=300)
	Image = models.ImageField(upload_to='photo')
	About_Tutor = models.TextField(max_length=1000, blank=False, default='About')
	def __str__(self):
		return self.Name

def validate_file_extension(value):
		import os
		ext = os.path.splitext(value.name)[1]
		valid_extensions = ['.pdf','.doc','.docx']
		if not ext in valid_extensions:
			raise ValidationError(u'File not supported!')

class become_tutor(models.Model):
	Name = models.CharField(max_length=300, blank=False)
	Age = models.IntegerField(default=18, blank=False)
	CATEGORY_CHOICES = (
            ('Male','Male'),
            ('Female','Female'),
            )
	Gender = models.CharField(max_length=200, choices = CATEGORY_CHOICES, default='Male', blank=False)
	Email = models.EmailField(max_length=300, blank=False, primary_key=True)
	Mobile_No = models.IntegerField(blank=False, default='1234567890')
	Address = models.CharField(max_length=1000, blank=False)
	INTEREST_CHOICES = (
            ('Home_Tutions','Home Tutions'),
            ('Coaching_Classes','Coaching Classes'),
			('Homework_Help[Email]','Homework Help[Email]'),            
            )
	Interested_In = models.CharField(max_length=300, choices=INTEREST_CHOICES, blank=False)
	Qualifications = models.CharField(max_length=200, blank=False, default='MCA')
	SELECT='sl'
	ASP='asp'
	PYTHON='py'
	JAVA='ja'
	PHP='ph'
	ROR = 'ro'
	JUMLA = 'ju'
	COBOL = 'co'
	PASCAL = 'sa'
	BIGDATA = 'bi'
	DJANGO = 'dj'
	FLASK = 'fl'
	PYRAMID = 'py'
	VB = 'vb'
	WORDPRESS = 'wo'
	MAJENTO = 'mj'
	DRUPAL = 'dr'
	WEEBLY = 'we'
	SHOPIFY = 'sh'
	SPARESPACE = 'sp'

	Subject_Choices=(
		(SELECT, 'Select'),
		(ASP, 'Asp.net'),
		(PYTHON, 'Python'),
		(JAVA, 'Java'),
		(PHP, 'PHP'),
		(ROR, 'ROR'),
		(JUMLA,'Jumla'),
		(COBOL,'COBOL'),
		(PASCAL,'PASCAL'),
		(BIGDATA,'BigData'),
		(DJANGO,'Django'),
		(FLASK,'Flask'),
		(PYRAMID,'Pyramid'),
		(VB,'Vb.Net'),
		(WORDPRESS,'Wordpress'),
		(MAJENTO,'Majento'),
		(DRUPAL,'Drupal'),
		(WEEBLY,'Weebly'),
		(SHOPIFY,'Shopify'),
		(SPARESPACE,'Sparespace'),

		)
	Select_Subjects = models.CharField(max_length=300, choices=Subject_Choices, blank=False)
	Classes_Choices = (
		('Junior[I-V]','Junior[I-V]'),
		('Middle[VI-X]','Middle[VI-X]'),
		('Higher[XI-XII]','Higher[XI-XII]'),
		('Graduate','Graduate'),
		('Post Graduate','Post Graduate'),
		)
	Interested_Classes = models.CharField(max_length=300, choices=Classes_Choices, blank=False)
	About_You = models.TextField(max_length=900, blank=False, default='About')
	CATEGORY_CHOICES = (
            ('Chandigarh','Chandigarh'),
            ('Mohali','Mohali'),
            ('Kharar','Kharar'),
            )
	Select_Area = models.CharField(max_length=300, choices=CATEGORY_CHOICES, blank=False)
	
	Image = models.ImageField(upload_to='photo')

	

	Resume = models.FileField(upload_to='Tutor_resumes', validators=[validate_file_extension])
	def __str__(self):
		return self.Name
			
		
class Hire_Tutor(models.Model):
	Name = models.CharField(max_length=300, blank=False)
	Age = models.IntegerField(default=18, blank=False)
	CATEGORY_CHOICES = (
            ('Male','Male'),
            ('Female','Female'),
            )
	Gender = models.CharField(max_length=200, choices = CATEGORY_CHOICES, default='Male', blank=False)
	Email = models.EmailField(primary_key=True)
	Mobile_No = models.IntegerField(blank=False, default='1234567890')
	Address = models.CharField(max_length=1000, blank=False)	
	
	SELECT='sl'
	CHANDIGARH='ch'
	MOHALI='mh'
	KHARAR='kr'
	BELONGI='bl'
	area_choices=(
		(SELECT, 'Select'),
		(CHANDIGARH, 'Chandigarh'),
		(MOHALI, 'Mohali'),
		(KHARAR, 'Kharar'),
		(BELONGI, 'Belongi')

		)
	Select_Area = models.CharField(max_length=300, choices=area_choices, blank=False)
	Standard = models.CharField(max_length=300, blank=False)
	School = models.CharField(max_length=300, blank=False)
	Subject = models.CharField(max_length=300, blank=False)
	SELECT='sl'
	CHANDIGARH='ch'
	MOHALI='mh'
	KHARAR='kr'
	BELONGI='bl'
	area_choices=(
		(SELECT, 'Select'),
		(CHANDIGARH, 'Chandigarh'),
		(MOHALI, 'Mohali'),
		(KHARAR, 'Kharar'),
		(BELONGI, 'Belongi')

		)
	Tution_Area = models.CharField(max_length=300, choices=area_choices, blank=False)
	def __str__(self):
		return self.Name



class best_tutor(models.Model):
	CATEGORY_CHOICES = (
            ('Chandigarh','Chandigarh'),
            ('Mohali','Mohali'),
            ('Kharar','Kharar'),
            )
	Area = models.CharField(max_length=300, choices=CATEGORY_CHOICES)
	GENDER_CHOICES = (
            ('Male','Male'),
            ('Female','Female'),
            )
	Gender = models.CharField(max_length=200, choices = GENDER_CHOICES, default='Male', blank=False)

	Subject_Choices=(
		('ASP', 'Asp.net'),
		('PYTHON', 'Python'),
		('JAVA', 'Java'),
		('PHP', 'PHP'),
		('ROR', 'ROR'),
		('JUMLA','Jumla'),
		('COBOL','COBOL'),
		('PASCAL','PASCAL'),
		('BIGDATA','BigData'),
		('DJANGO','Django'),
		('FLASK','Flask'),
		('PYRAMID','Pyramid'),
		('VB','Vb.Net'),
		('WORDPRESS','Wordpress'),
		('MAJENTO','Majento'),
		('DRUPAL','Drupal'),
		('WEEBLY','Weebly'),
		('SHOPIFY','Shopify'),
		('SPARESPACE','Sparespace'),

		)
	Subjects = models.CharField(max_length=300, choices=Subject_Choices, blank=False)
	Classes_Choices = (
		('Junior[I-V]','Junior[I-V]'),
		('Middle[VI-X]','Middle[VI-X]'),
		('Higher[XI-XII]','Higher[XI-XII]'),
		('Graduate','Graduate'),
		('Post Graduate','Post Graduate'),
		)
	Classes = models.CharField(max_length=300, choices=Classes_Choices, blank=False)
	experience_Choices = (
		('Less Than One Year','Less Than One Year'),
		('1+','1+'),
		('2+','2+'),
		('3+','3+'),
		('4+','4+'),
		('5+','5+'),
		('6+','6+'),
		('7+','7+'),
		('8+','8+'),
		('9+','9+'),
		('10+','10+'),
		('11+','11+'),
		('12+','12+'),
		('13+','13+'),
		('14+','14+'),
		('15+','15+'),
		('16+','16+'),
		('17+','17+'),
		('18+','18+'),
		('19+','19+'),
		('20+','20+'),
		)
	Experience = models.CharField(max_length=300, choices=experience_Choices, blank=False)
	age_Choices = (
		('Any','Any'),
		('18+','18+'),
		('19+','19+'),
		('20+','20+'),
		('21+','21+'),
		('22+','22+'),
		('23+','23+'),
		('24+','24+'),
		('25+','25+'),
		('26+','26+'),
		('27+','27+'),
		('28+','28+'),
		('29+','29+'),
		('30+','30+'),
		('31+','31+'),
		('32+','32+'),
		('33+','33+'),
		('34+','34+'),
		('35+','35+'),
		('36+','36+'),
		('37+','37+'),
		('38+','38+'),
		('39+','39+'),
		('40+','40+'),
		('41+','41+'),
		('42+','42+'),
		('43+','43+'),
		('44+','44+'),
		('45+','45+'),
		('46+','46+'),
		('47+','47+'),
		('48+','48+'),
		('49+','49+'),
		('50+','50+'),
		('51+','51+'),
		('52+','52+'),
		('53+','53+'),
		('54+','54+'),
		('55+','55+'),
		('56+','56+'),
		('57+','57+'),
		)

	Age = models.CharField(max_length=300, choices=age_Choices, blank=False)
	charges_Choices = (
		('Any','Any'),
		('100','100'),
		('150','150'),
		('200','200'),
		('250','250'),
		('300','300'),
		('350','350'),
		('400','400'),
		('450','450'),
		('500','500'),
		('550','550'),
		('600','600'),
		('650','650'),
		('700','700'),
		('750','750'),
		('800','800'),
		('850','850'),
		('900','900'),
		('950','950'),
		('1000','1000'),
		)

	Charges_Per_Hour = models.CharField(max_length=300, choices=charges_Choices, blank=False)

	rating_choices= (
		('No Rating','No Rating'),
		('1 Star','1 Star'),
		('2 Star','2 Star'),
		('3 Star','3 Star'),
		('4 Star','4 Star'),
		('5 Star','5 Star'),
		)
	Ratings = models.CharField(max_length=300, choices=rating_choices, blank=False)
	def __str__(self):
		return self.Subjects



